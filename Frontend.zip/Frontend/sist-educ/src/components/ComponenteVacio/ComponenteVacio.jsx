import React from 'react'

function ComponenteVacio() {
  return (
    <div><p>Componente vacio</p></div>
  )
}

export default ComponenteVacio